package arcade;
import java.util.*;
public class ExpChain {
    public static void main(String[] x){
        Game g=new Game(42,Game.Mode.SOLO,Game.Theme.VILLAGE,0);for(int[] r:g.tiles)Arrays.fill(r,0);g.state=Game.State.PLAYING;
        Game.Bomb a=new Game.Bomb(2,2,0,3),b=new Game.Bomb(4,2,1,2);g.bombs.add(a);g.bombs.add(b);
        try{g.explode(a);System.out.println("연쇄 폭발 정상: 남은 풍선="+g.bombs.size()+" 폭발 횟수="+g.explosionSerial+" 물줄기 칸="+g.blasts.size());}
        catch(StackOverflowError e){System.out.println("StackOverflowError 발생: explode() 호출 횟수="+g.explosionSerial+" 남은 풍선="+g.bombs.size());}
    }
}
