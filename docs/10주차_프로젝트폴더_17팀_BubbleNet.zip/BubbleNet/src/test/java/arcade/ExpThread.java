package arcade;
import java.util.*;
public class ExpThread {
    public static void main(String[] a)throws Exception{
        int failed=0;String first=null;
        for(int trial=0;trial<20;trial++){
            Game g=new Game(42,Game.Mode.SOLO,Game.Theme.VILLAGE,0);for(int[] r:g.tiles)Arrays.fill(r,0);g.state=Game.State.PLAYING;
            for(Game.Player p:g.players){p.decision=1e9;p.capacity=6;}
            final Throwable[] err=new Throwable[1];
            Thread tick=new Thread(()->{try{for(int i=0;i<200000&&err[0]==null;i++){g.update(1.0/60);g.remaining=180;for(Game.Player p:g.players){p.life=Game.Life.ACTIVE;}}}catch(Throwable t){err[0]=t;}},"tick");
            Thread input=new Thread(()->{try{Random r=new Random(1);for(int i=0;i<200000&&err[0]==null;i++){Game.Player p=g.players.get(r.nextInt(4));p.bombCooldown=0;g.place(p);g.move(p,r.nextInt(4));}}catch(Throwable t){err[0]=t;}},"input");
            tick.start();input.start();tick.join();input.join();
            if(err[0]!=null){failed++;if(first==null)first=err[0].toString();}
        }
        System.out.println("스레드 2개(틱 스레드 + 입력 스레드)가 같은 Game을 동시에 사용: 20회 중 "+failed+"회 예외");
        System.out.println("첫 예외: "+first);
    }
}
