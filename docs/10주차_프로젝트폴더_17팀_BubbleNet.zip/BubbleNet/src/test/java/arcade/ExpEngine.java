package arcade;
import java.util.*;
public class ExpEngine {
    static String run(long seed,double dt){
        Game g=new Game(seed,Game.Mode.SOLO,Game.Theme.VILLAGE,0);g.state=Game.State.PLAYING;
        int frames=0;
        while(g.state==Game.State.PLAYING&&frames<200000){for(Game.Player p:g.players)if(!p.bot&&frames%6==0)g.think(p);g.update(dt);frames++;}
        StringBuilder sb=new StringBuilder();for(Game.Player p:g.players)sb.append(p.life.name().charAt(0)).append(p.x).append(',').append(p.y).append(' ');
        return String.format("result=%-9s elapsed=%7.3fs frames=%5d explosions=%3d players=[%s]",g.result,g.elapsed,frames,g.explosionSerial,sb.toString().trim());
    }
    static int crates(long seed){Game g=new Game(seed,Game.Mode.SOLO,Game.Theme.VILLAGE,0);int n=0;for(int[] r:g.tiles)for(int t:r)if(t==2)n++;return n;}
    public static void main(String[] a){
        System.out.println("[A] 같은 시드 2회 / 다른 시드");
        System.out.println(" seed=7  #1 "+run(7,1.0/60));
        System.out.println(" seed=7  #2 "+run(7,1.0/60));
        System.out.println(" seed=8     "+run(8,1.0/60));
        System.out.println(" 상자 수 seed=7:"+crates(7)+" seed=7:"+crates(7)+" seed=8:"+crates(8));
        System.out.println("[C] 같은 시드, dt만 변경");
        System.out.println(" dt=1/60    "+run(7,1.0/60));
        System.out.println(" dt=1/30    "+run(7,1.0/30));
        System.out.println(" dt=1/20    "+run(7,1.0/20));
        System.out.println("[D] update() 1회 평균 시간");
        for(int rep=0;rep<3;rep++){
            Game g=new Game(rep,Game.Mode.SOLO,Game.Theme.VILLAGE,0);g.state=Game.State.PLAYING;int n=0;long t=System.nanoTime();
            while(g.state==Game.State.PLAYING){for(Game.Player p:g.players)if(!p.bot&&n%6==0)g.think(p);g.update(1.0/60);n++;}
            double us=(System.nanoTime()-t)/1e3/n;System.out.printf(" seed=%d  %d회  평균 %.1f µs/회 (60Hz 한 틱 16,667 µs의 %.2f%%)%n",rep,n,us,us/16667*100);
        }
    }
}
