package arcade;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
public class ExpUi {
    static void paint(Main.Panel p){BufferedImage i=new BufferedImage(p.getWidth(),p.getHeight(),BufferedImage.TYPE_INT_ARGB);var g=i.createGraphics();p.paint(g);g.dispose();}
    static void click(Main.Panel p,int x,int y){MouseEvent e=new MouseEvent(p,MouseEvent.MOUSE_PRESSED,0,0,x,y,1,false,MouseEvent.BUTTON1);for(MouseListener l:p.getMouseListeners())l.mousePressed(e);}
    public static void main(String[] a)throws Exception{
        System.setProperty("java.awt.headless","true");
        SwingUtilities.invokeAndWait(()->{try{
            System.out.println("[F] 고정 시간 간격(accumulator): tick() 호출 간격을 바꿔도 게임 시간이 실제 시간과 같은지");
            for(int gap:new int[]{16,50,90}){
                Main.Panel p=new Main.Panel(false);p.setSize(800,600);p.start();p.game.state=Game.State.PLAYING;for(Game.Player q:p.game.players)q.decision=1e9;
                p.last=System.nanoTime();long t0=System.nanoTime();int calls=0;
                while(System.nanoTime()-t0<1_000_000_000L){Thread.sleep(gap);p.tick();calls++;}
                double real=(System.nanoTime()-t0)/1e9;
                System.out.printf("  tick 간격 %3dms: tick %3d회, 실제 %.3fs, 게임 시간 %.3fs, update %d회%n",gap,calls,real,p.game.elapsed,Math.round(p.game.elapsed*60));
            }
            Main.Panel p=new Main.Panel(false);p.setSize(800,600);p.start();p.game.state=Game.State.PLAYING;for(Game.Player q:p.game.players)q.decision=1e9;
            p.last=System.nanoTime();Thread.sleep(1000);p.tick();
            System.out.printf("  1000ms 멈춘 뒤 tick 1회: 게임 시간 %.3fs (dt 상한 0.1초)%n",p.game.elapsed);

            System.out.println("[G] 키 반복 입력: ESC 눌림 이벤트를 뗌 없이 3번 전달");
            p=new Main.Panel(false);p.setSize(800,600);p.start();p.game.state=Game.State.PLAYING;
            Action press=p.getActionMap().get(KeyEvent.VK_ESCAPE+":false"),release=p.getActionMap().get(KeyEvent.VK_ESCAPE+":true");
            for(int i=0;i<3;i++){press.actionPerformed(null);System.out.println("  눌림 "+(i+1)+"회째 -> "+p.game.state);}
            release.actionPerformed(null);press.actionPerformed(null);System.out.println("  뗀 뒤 다시 눌림 -> "+p.game.state);

            System.out.println("[I] 창 크기 변경 시 마우스 좌표 변환: '게임 시작' 버튼(논리 좌표 684,512) 클릭");
            int[][] sizes={{800,600},{1200,900},{1600,900},{600,800}};
            for(int[] s:sizes){
                p=new Main.Panel(false);p.setSize(s[0],s[1]);paint(p);
                double sc=Math.min(s[0]/800.0,s[1]/600.0);int mx=(int)((s[0]-800*sc)/2+684*sc),my=(int)((s[1]-600*sc)/2+512*sc);
                click(p,mx,my);boolean scaled=p.game!=null;
                Main.Panel q=new Main.Panel(false);q.setSize(s[0],s[1]);paint(q);click(q,684,512);
                System.out.printf("  창 %4dx%-4d 배율 %.2f: 변환 좌표(%4d,%4d) 클릭 -> %s / 변환 없이 (684,512) 클릭 -> %s%n",s[0],s[1],sc,mx,my,scaled?"게임 시작":"반응 없음",q.game!=null?"게임 시작":"반응 없음");
            }
        }catch(Exception e){throw new RuntimeException(e);}});
        System.out.println("[E] 물풍선 애니메이션 프레임 전환 횟수(설치 후 1초, 3프레임 스프라이트)");
        int now=0,old=0,pn=-1,po=-1;
        for(int i=0;i<=1000;i++){double t=i/1000.0,clock=5+t; // clock: 전역 시간, t: 설치 후 경과
            int fn=Math.floorMod((int)(t*5),3),fo=Math.floorMod((int)((clock+t*2)*5),3);
            if(pn>=0&&fn!=pn)now++;if(po>=0&&fo!=po)old++;pn=fn;po=fo;}
        System.out.println("  현재 식 floor(t*5)%3            : 1초에 "+now+"회 전환");
        System.out.println("  이전 식 floor((clock+t*2)*5)%3  : 1초에 "+old+"회 전환");
        System.exit(0);
    }
}
